﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodShortage
{
    interface IIdentifiable
    {
        string Id { get; }
    }
}
