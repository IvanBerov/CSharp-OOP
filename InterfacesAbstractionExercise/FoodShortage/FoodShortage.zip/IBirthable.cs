﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodShortage
{
    interface IBirthable
    {
        string Birthdate { get; }
    }
}
